// varification-user.component.ts

import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { WebSocketService } from '../services/service.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-varification-user',
  templateUrl: './varification-user.component.html',
  styleUrls: ['./varification-user.component.css'],
})
export class VarificationUserComponent implements OnInit, OnDestroy {
  verificationForm!: FormGroup;
  userVerified = false;
  userVerifiedFail = false;
  errorMessage = '';
  isSubmit = false;
  private messageSubscription: Subscription | undefined;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private webSocketService: WebSocketService
  ) {}

  ngOnInit() {
    this.initWebSocketSubscription();
    this.setupVerificationForm();
  }

  private initWebSocketSubscription() {
    const websocket = this.webSocketService.getWebSocket();

    if (websocket) {
      // Subscribe to WebSocket messages
      this.messageSubscription = this.webSocketService.receiveMessages().subscribe((event) => {
        this.handleWebSocketMessage(event);
      });
    }
  }

  private setupVerificationForm() {
    this.verificationForm = this.formBuilder.group({
      password: ['', Validators.required],
      totac: ['', Validators.required],
    });
  }

  private handleWebSocketMessage(event: any) {
    const message = event;
    console.log('Received message verified:', message);
    console.log('this.webSocketService.getTabId()',this.webSocketService.getTabId());
    
    const jsonData = JSON.parse(message) || '';

    console.log('recived tab id => ',jsonData.tabId);
    console.log('recived tab id 1  => ',this.webSocketService.getTabId());
    
    if (jsonData.tabId == this.webSocketService.getTabId()) {
      console.log('1111111111111=>',message);
      
      if (jsonData.status == '0' && jsonData.jsessionid == localStorage.getItem('jsessionid')) {
        console.log('Tatcode success');
        this.userVerified = true;
        this.errorMessage = 'Login success';
        this.router.navigate(['/dashboard']);
      }
     // console.log('out side');
      
      if (jsonData.status == '1' && jsonData.jsessionid == localStorage.getItem('jsessionid') ) {
        
        console.log('Tatcode login fail');
        this.userVerifiedFail = true;
        this.errorMessage = jsonData.errormsg;
      }
    }
  }

  onSubmit() {
    const messageToSend = {
      userName: localStorage.getItem('userName'),
      password: this.verificationForm.get('password')?.value,
      totac: this.verificationForm.get('totac')?.value,
    };

    console.log('messageToSend--->', messageToSend);

    const websocket = this.webSocketService.getWebSocket();
    if (websocket && websocket.readyState === WebSocket.OPEN) {
      console.log('fff');
      // Send message to the WebSocket
      this.webSocketService.sendMessage(JSON.stringify(messageToSend));
    }
    
  }

  ngOnDestroy() {
    // Unsubscribe from WebSocket messages to prevent memory leaks
    if (this.messageSubscription) {
      this.messageSubscription.unsubscribe();
    }
  }
}
