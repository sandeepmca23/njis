// login.component.ts

import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { WebSocketService } from '../services/service.service';
import { Subscription } from 'rxjs';

@Component({
  templateUrl: 'login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit, OnDestroy {
  loginForm!: FormGroup;
  NONMFA = false;
  userVerified = false;
  userVerifiedFail = false;
  errorMessage = '';
  isSubmit = false;
  isTimeOutOrInvalidCred: any;
  private messageSubscription: Subscription | undefined;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private webSocketService: WebSocketService
  ) {}

  ngOnInit() {
    this.isTimeOutOrInvalidCred = localStorage.getItem('isTimeOutOrInvalidCred');
    localStorage.clear();
    console.log('this.isTimeOutOrInvalidCred', this.isTimeOutOrInvalidCred);

    this.loginForm = this.formBuilder.group({
      userName: ['', Validators.required],
    });

    // Subscribe to WebSocket messages
    this.messageSubscription = this.webSocketService.receiveMessages().subscribe((event: any) => {
      this.handleWebSocketMessage(event);
    });
  }

  onSubmit() {
    this.isSubmit = true;
    const messageToSend = {
      userName: this.loginForm.get('userName')?.value,
    };
  
    const websocket = this.webSocketService.getWebSocket();
  
    if (websocket && websocket.readyState === WebSocket.OPEN) {
      // Send message to the WebSocket
      this.webSocketService.sendMessage(JSON.stringify(messageToSend));
    }
  }

  onUserNameChange() {
    this.isSubmit = false; // Reset isSubmit when the username is changed
  }

  ngOnDestroy() {
    // Unsubscribe from WebSocket messages to prevent memory leaks
    if (this.messageSubscription) {
      this.messageSubscription.unsubscribe();
    }
  }

  private handleWebSocketMessage(event: any) {
    const message = event;
    console.log('Received message:', message);
    const jsonData = JSON.parse(message) || '';
    if (jsonData.tabId === this.webSocketService.getTabId()) {
      if (jsonData.status == '1') {
        console.log('Login fail');
        this.userVerifiedFail = true;
        this.errorMessage = jsonData.errormsg; //'Login fail';
      }
      if (jsonData.authType == 'MFA' && jsonData.status == '0') {
        console.log('MFA call');
        localStorage.setItem('userName', jsonData.userName);
        localStorage.setItem('jsessionid', jsonData.jsessionid);
        this.router.navigate(['/user-verify']);
      }
      if (jsonData.authType == 'PWL' && jsonData.status == '0') {
        console.log('PWL call');
        this.NONMFA = true;
        localStorage.setItem('userName', jsonData.userName);
        localStorage.setItem('jsessionid', jsonData.jsessionid);
        this.router.navigate(['/waiting-time']);
      }
    }
  }

  // private handleWebSocketMessage(event: any) {
  //   const jsonData = JSON.parse(event) || '';

  //   // Verify tabId
  //   if (jsonData.tabId === this.webSocketService.getTabId()) {
  //     if (jsonData.status === 0 && jsonData.authType === 'MFA') {
  //       // Move to the next screen (e.g., user-verify route)
  //       localStorage.setItem('userName', jsonData.userName);
  //       localStorage.setItem('jsessionid', jsonData.jsessionid);
  //       this.router.navigate(['/user-verify']);
  //     }
  //   }
  // }
  
}
