import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WebSocketService } from '../services/service.service'; // Update the path

@Component({
  selector: 'app-waiting-time',
  templateUrl: './waiting-time.component.html',
  styleUrls: ['./waiting-time.component.css'],
})
export class WaitingTimeComponent implements OnInit {
  showLoader: boolean = true;
  remainingMinutes: number = 10;
  remainingSeconds: number = 0;
  userVerified = false;
  userVerifiedFail = false;
  errorMessage = '';
  constructor(
    private router: Router,
    private webSocketService: WebSocketService
  ) {}
  ngOnInit() {
    let totalTimeInSeconds = this.remainingMinutes * 60 + this.remainingSeconds;

    const countdownInterval = setInterval(() => {
      totalTimeInSeconds--;

      this.remainingMinutes = Math.floor(totalTimeInSeconds / 60);
      this.remainingSeconds = totalTimeInSeconds % 60;

      if (totalTimeInSeconds <= 0) {
        clearInterval(countdownInterval);
        this.showLoader = false;
        localStorage.setItem(
          'isTimeOutOrInvalidCred',
          'Please Try again latter'
        );

        this.router.navigate(['/login']);
      }
    }, 1000); // Update every second

    const websocket = this.webSocketService.getWebSocket();
    if (websocket) {
      websocket.addEventListener('message', (event) => {
        const message = event.data;
        console.log('Received message verified:', message);

        const jsonData = JSON.parse(message) ? JSON.parse(message) : '';
        if (jsonData.tabId == this.webSocketService.getTabId()) {
          if (
            jsonData.status == '0' &&
            jsonData.jsessionid == localStorage.getItem('jsessionid')
          ) {
            console.log('verification login success');
            this.userVerified = true;
            this.errorMessage = 'Login success';
            setTimeout(() => {
              this.router.navigate(['/dashboard']);
            }, 5000);
          }
          if (jsonData.status == '1' &&
          jsonData.jsessionid == localStorage.getItem('jsessionid')) {
            console.log('verification login fail');
            this.userVerifiedFail = true;
            this.errorMessage = jsonData.errormsg;
            
            localStorage.setItem('isTimeOutOrInvalidCred', jsonData.errormsg);
            this.router.navigate(['/login']);
          }
        }
      });
    }
  }
}
