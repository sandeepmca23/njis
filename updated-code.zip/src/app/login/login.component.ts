import { CommonModule } from '@angular/common';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { WebSocketService } from '../services/service.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent implements OnInit, OnDestroy {
  isLoginPage = true;
  isVarifyUserPage = false;
  isWaitingTimePage = false;
  loginForm!: FormGroup;
  NONMFA = false;
  userVerified = false;
  userVerifiedFail = false;
  isSubmitForm = false;
  errorMessage = '';
  isSubmit = false;
  private messageSubscription: Subscription | undefined;
  timeOutMessage: string = '';

  //VarificationUserComponent
  verificationForm!: FormGroup;

  //WaitingTimeComponent
  showLoader: boolean = true;
  remainingMinutes: number = 10;
  remainingSeconds: number = 0;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private webSocketService: WebSocketService
  ) {}

  ngOnInit() {
    localStorage.clear();

    this.loginForm = this.formBuilder.group({
      userName: ['', Validators.required],
    });

    // Subscribe to WebSocket messages
    this.messageSubscription = this.webSocketService
      .receiveMessages()
      .subscribe((event: any) => {
        this.handleWebSocketMessage(event);
      });

    //VarificationUserComponent
    this.initWebSocketSubscription();
    this.setupVerificationForm();

    //WaitingTimeComponent
    // this.waitingTime();




    const websocket = this.webSocketService.getWebSocket();

    if (websocket) {
      websocket.addEventListener('message', (event) => {
        const message = event.data;
        const jsonData = JSON.parse(message) ? JSON.parse(message) : '';

        if (
          jsonData.userSessionId == this.webSocketService.getUserSessionId()
        ) {
          if (jsonData?.status == 'SUCCESS') {
            console.log('verification login success');
            this.userVerified = true;
            this.errorMessage = '';
            if (this.isWaitingTimePage && jsonData?.json?.authToken) {
              localStorage.setItem('authToken', jsonData?.json.authToken);
              this.router.navigate(['/home']);
            }
          }
          if (jsonData?.status == 'FAILURE') {
            console.log('verification login fail');
            this.userVerifiedFail = true;
            this.errorMessage = jsonData.message;            
            // this.router.navigate(['/login']);
            if(this.isLoginPage){
              this.isLoginPage = true;
            }
            this.isWaitingTimePage = false;
            localStorage.clear();
          }
          if (jsonData?.status == 'TRN_IN_PROGRESS') {
            this.userVerifiedFail = true;
            this.errorMessage = jsonData.message;
            console.log('this.errorMessage', this.errorMessage);
          }
        }
      });
    }
  }

  onSubmit() {
    if (this.isLoginPage) {
      this.isSubmit = true;
      const messageToSend = {
        userName: this.loginForm.get('userName')?.value,
        datasource: 'NJIIS',
        action: 'GENERATE_TOTAC',
      };

      const websocket = this.webSocketService.getWebSocket();

      if (websocket && websocket.readyState === WebSocket.OPEN) {
        // Send message to the WebSocket
        this.webSocketService.sendMessage(JSON.stringify(messageToSend));
      }
    }
    if (this.isVarifyUserPage) {
      this.isSubmitForm = true;
      const messageToSend = {
        userName: localStorage.getItem('userName'),
        password: this.verificationForm.get('password')?.value,
        totac: this.verificationForm.get('totac')?.value,
        datasource: 'NJIIS',
        action: 'VALIDATE_MFA_TOTAC',
      };
      const websocket = this.webSocketService.getWebSocket();
      if (websocket && websocket.readyState === WebSocket.OPEN) {
        // Send message to the WebSocket
        this.webSocketService.sendMessage(JSON.stringify(messageToSend));
      }
    }
  }

  countDown(){
    this.showLoader = true;
    let totalTimeInSeconds = this.remainingMinutes * 60 + this.remainingSeconds;

    const countdownInterval = setInterval(() => {
      totalTimeInSeconds--;

      this.remainingMinutes = Math.floor(totalTimeInSeconds / 60);
      this.remainingSeconds = totalTimeInSeconds % 60;
      
      if (totalTimeInSeconds <= 0 && this.isWaitingTimePage) {
        clearInterval(countdownInterval);
        this.showLoader = false;
        this.timeOutMessage = 'Please Try again latter';

        // this.router.navigate(['/login']);
        this.isLoginPage = true;
        this.remainingMinutes = 10;
        this.isWaitingTimePage = false;
      }
    }, 1000);
    this.timeOutMessage = ""
  }

  onUserNameChange(form: any) {
    if (form == 1) {
      this.isSubmit = false;
      this.errorMessage = ''; 
      this.timeOutMessage = ""// Reset isSubmit when the username is changed
    }
    if (form == 2) {
      this.isSubmitForm = false;
      this.errorMessage = ''; 
      this.timeOutMessage = ""// Reset isSubmit when the username is changed
    }
  }

  ngOnDestroy() {
    // Unsubscribe from WebSocket messages to prevent memory leaks
    if (this.messageSubscription) {
      this.messageSubscription.unsubscribe();
    }
  }

  private handleWebSocketMessage(event: any) {
    if (this.isLoginPage) {
      const message = event;
      console.log('Received message:', message);
      const jsonData = JSON.parse(message) || '';
      console.log('jsonData', jsonData);
      if (jsonData.userSessionId === this.webSocketService.getUserSessionId()) {
        if (jsonData?.status == 'FAILURE') {          
          this.userVerifiedFail = true;
          this.isLoginPage = true;
          this.isVarifyUserPage = false
          this.errorMessage = jsonData.message; //'Login fail';
        }
        if (
          jsonData?.json?.authType == 'MFA' &&
          jsonData?.status == 'SUCCESS'
        ) {
          localStorage.setItem('userName', jsonData.userName);
          // this.router.navigate(['/user-verify']);
          this.isLoginPage = false;
          this.isVarifyUserPage = true;
        }
        if (
          jsonData?.json?.authType == 'PLA' &&
          jsonData?.status == 'SUCCESS'
        ) {
          console.log('PWL call');
          this.NONMFA = true;
          localStorage.setItem('userName', jsonData.userName);

          // this.router.navigate(['/waiting-time']);
          this.isLoginPage = false;
          this.isWaitingTimePage = true;
          this.testFuncation();
          this.countDown();
        }
      }
    }

    if (this.isVarifyUserPage) {
      const message = event;
      console.log('Received message verified:', message);
      const jsonData = JSON.parse(message) || '';
      if (jsonData.userSessionId == this.webSocketService.getUserSessionId()) {
        //console.log('1111111111111=>', message);
        if (jsonData?.status == 'SUCCESS') {
          this.userVerified = true;
          this.errorMessage = 'Login success';
          localStorage.setItem('authToken', jsonData?.json.authToken);
          localStorage.setItem('userName', jsonData.userName);
          if (this.isVarifyUserPage && this.isSubmitForm) {
            this.router.navigate(['/home']);
          }
        }
        if (jsonData?.status == 'FAILURE' 
        ) {
          console.log('Tatcode login fail');
         // this.userVerifiedFail = true;
          this.errorMessage = jsonData.message;
          this.isVarifyUserPage = true;
          this.isLoginPage = false;
        }
      }
    }
  }

  private testFuncation() {
    const messageToSend = {
      datasource: 'NJIIS',
      action: 'GET_PLA_AUTH_TOKEN',
      userName: localStorage.getItem('userName'),
    };
    console.log('messageToSend', messageToSend);

    // Send message to the WebSocket
    this.webSocketService.sendMessage(JSON.stringify(messageToSend));
  }
  // VarificationUserComponent
  private initWebSocketSubscription() {
    const websocket = this.webSocketService.getWebSocket();

    if (websocket) {
      // Subscribe to WebSocket messages
      this.messageSubscription = this.webSocketService
        .receiveMessages()
        .subscribe((event) => {
          this.handleWebSocketMessage(event);
        });
    }
  }

  private setupVerificationForm() {
    this.verificationForm = this.formBuilder.group({
      password: ['', Validators.required],
      totac: ['', Validators.required],
    });
  }
  cancel() {
    this.isLoginPage = true;
    this.isWaitingTimePage = false;
    // this.loginForm.patchValue({
    //   userName: "",
    // });
    localStorage.clear();
  }

  waitingTime() {
    
  }
}
