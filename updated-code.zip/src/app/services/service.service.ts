import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class WebSocketService {
  private wsUri = 'wss://socketsbay.com/wss/v2/1/demo/';
 
  private websocket: WebSocket | undefined;
  private userSessionId;
  private messageSubject = new Subject<string>();

  constructor() {
    this.userSessionId =this.generateUniqueId(), this.connectWebSocket();
  }

  private generateUniqueId(): string {
    return '_' + Math.random().toString(36).substr(2, 9);
  }

  private connectWebSocket() {
    this.websocket = new WebSocket(`${this.wsUri}`);

    this.websocket.addEventListener('open', (event) => {
      console.log('WebSocket connection opened:', event);
    });

    this.websocket.addEventListener('close', (event) => {
      console.log('WebSocket connection closed:', event);
    });

    this.websocket.addEventListener('error', (event) => {
      console.error('WebSocket error:', event);
    });

    this.websocket.addEventListener('message', (event) => {
      // Handle received messages
      this.messageSubject.next(event.data);
    });
  }

  sendMessage2(message: string): void {
    if (this.websocket && this.websocket.readyState === WebSocket.OPEN) {
      this.websocket.send(
        JSON.stringify({ message, userSessionId: this.userSessionId })
      );
    }
  }

  sendMessage(message: string): void {
    console.log('dataToSend--------', 'dataToSend');
    if (this.websocket && this.websocket.readyState === WebSocket.OPEN) {
      const jsonData = JSON.parse(message) || {};
      jsonData['userSessionId'] = this.userSessionId;
      console.log('Bhavesh--->', JSON.stringify(jsonData));

      this.websocket.send(JSON.stringify(jsonData));
    }
  }

  receiveMessages(): Subject<string> {
    return this.messageSubject;
  }

  disconnect(): void {
    if (this.websocket) {
      this.websocket.close();
    }
  }

  getWebSocket(): WebSocket | undefined {
    return this.websocket;
  }

  getUserSessionId(): string {
    return this.userSessionId;
  }
}
