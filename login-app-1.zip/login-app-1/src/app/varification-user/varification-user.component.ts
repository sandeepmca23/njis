// varification-user.component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { WebSocketService } from '../services/service.service'; // Update the path accordingly

@Component({
  selector: 'app-varification-user',
  templateUrl: './varification-user.component.html',
  styleUrls: ['./varification-user.component.css'],
})
export class VarificationUserComponent implements OnInit {
  verificationForm!: FormGroup;
  userVerified = false;
  userVerifiedFail = false;
  errorMessage = '';
  isSubmit = false;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private webSocketService: WebSocketService
  ) {}

  ngOnInit() {

    
    this.verificationForm = this.formBuilder.group({
      password: ['', Validators.required],
      totac: ['', Validators.required],
    });

    const websocket = this.webSocketService.getWebSocket();

    if (websocket) {
      websocket.addEventListener('message', (event) => {
        const message = event.data;
        console.log('Received message verified:', message);

        const jsonData = JSON.parse(message) ? JSON.parse(message) : '';
        if (
          jsonData.status == '0' &&
          jsonData.jsessionid == sessionStorage.getItem('jsessionid')
        ) {
          console.log('Tatcode success');
          this.userVerified = true;
          this.errorMessage = 'Login success';
          setTimeout(() => {
            this.router.navigate(['/dashboard']);
          }, 5000);
        }
        if (jsonData.status == '1') {
          console.log('Tatcode login fail');
          this.userVerifiedFail = true;
          this.errorMessage = jsonData.errormsg;
          
        }
      });
    }
  }
  onSubmit() {
    const messageToSend = {
      userName: localStorage.getItem('userName'),
     
      password: this.verificationForm.get('password')?.value,
      totac: this.verificationForm.get('totac')?.value,
      jsessionid:  localStorage.getItem('jsessionid')
    };

    console.log('messageToSend--->', messageToSend);

    const websocket = this.webSocketService.getWebSocket();
    if (websocket && websocket.readyState === WebSocket.OPEN) {
      console.log('fff');

      websocket.send(JSON.stringify(messageToSend));
    }
  }
}
