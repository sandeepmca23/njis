// login.component.ts
import { Component, OnInit,inject } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { WebSocketService } from '../services/service.service'; // Update the path accordingly
import { LocalStorageService } from 'ngx-webstorage';


@Component({
  templateUrl: 'login.component.html',
  styleUrls: ['./login.component.css'],
 
})
export class LoginComponent implements OnInit {
  

  loginForm!: FormGroup;
  NONMFA = false;
  //formSubmitted = false;
  userVerified = false;
  userVerifiedFail = false;
  errorMessage = '';
  isSubmit = false;
  isTimeOutOrInvalidCred: any;
 
  jsessionid:any;
  

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private webSocketService: WebSocketService,private storage: LocalStorageService
  ) {

   
  }

  ngOnInit() {
    
    this.isTimeOutOrInvalidCred = localStorage.getItem(
      'isTimeOutOrInvalidCred'
      );
      localStorage.clear();
      console.log('this.isTimeOutOrInvalidCred', this.isTimeOutOrInvalidCred);
      
    this.loginForm = this.formBuilder.group({
      userName: ['', Validators.required],
    });
  }

  onSubmit() {
    // this.formSubmitted = true;
    console.log('submit '); 
    this.isSubmit = true;
    this.jsessionid=new Date().getTime()+"@"+Math.floor(Math.random() * 1000);
    console.log(this.jsessionid);
    //this.storage.store('jsessionid',  this.jsessionid);
        const messageToSend = {
      userName: this.loginForm.get('userName')?.value,
      jsessionid:this.jsessionid
    };

    sessionStorage.setItem('jsessionid',  this.jsessionid);
    sessionStorage.setItem('userName', messageToSend.userName);

    const websocket = this.webSocketService.getWebSocket();
    if (websocket && websocket.readyState === WebSocket.OPEN) {
      websocket.send(JSON.stringify(messageToSend));
      console.log('call');
      websocket.addEventListener('message', (event) => {
        const message = event.data;
        console.log('Received message:', message);
        const jsonData = JSON.parse(message) ? JSON.parse(message) : '';
        console.log('jsonData:', jsonData);

        
        if (jsonData.status == '1') {
          console.log('Login fail');
          this.userVerifiedFail = true;
          this.errorMessage = jsonData.errormsg; //'Login fail';
          
        }
        
        if (jsonData.authType == 'MFA' && jsonData.status == '0' && this.jsessionid==jsonData.jsessionid) {
          console.log('MFA call');
         // sessionStorage.setItem('userName', jsonData.userName);
          sessionStorage.setItem('jsessionid', jsonData.jsessionid);
          this.router.navigate(['/user-verify']);
        }
        if (jsonData.authType == 'PWL' && jsonData.status == '0' && this.jsessionid==jsonData.jsessionid) {
          console.log('PWL call');
          this.NONMFA = true;
          //sessionStorage.setItem('userName', jsonData.userName);
          sessionStorage.setItem('jsessionid', jsonData.jsessionid);
          this.router.navigate(['/waiting-time']);
        }
      });
    }
  }
 
  onUserNameChange() {
    this.isSubmit = false; // Reset isSubmit when the username is changed
  }
}
