// websocket.service.ts
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class WebSocketService {
  private wsUri = 'wss://socketsbay.com/wss/v2/1/demo/';
  private websocket: WebSocket | undefined;

  constructor() {
    this.connectWebSocket();
  }

  private connectWebSocket() {
    this.websocket = new WebSocket(this.wsUri);

    this.websocket.addEventListener('open', (event) => {
      console.log('WebSocket connection opened:', event);
    });

    this.websocket.addEventListener('close', (event) => {
      console.log('WebSocket connection closed:', event);
    });

    this.websocket.addEventListener('error', (event) => {
      console.error('WebSocket error:', event);
    });
  }

  getWebSocket(): WebSocket | undefined {
    return this.websocket;
  }
}
